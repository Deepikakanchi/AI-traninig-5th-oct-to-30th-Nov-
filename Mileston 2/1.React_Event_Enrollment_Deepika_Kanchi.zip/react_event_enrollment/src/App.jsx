import { useMemo, useState } from 'react'
import { BrowserRouter, Link, NavLink, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import './App.css'

const EVENTS = [
  { id: 'EV101', title: 'Intro to Cloud Computing', category: 'Technology', date: '2026-11-10', time: '10:00', seats: 4 },
  { id: 'EV102', title: 'Creative Writing Lab', category: 'Arts', date: '2026-11-12', time: '14:00', seats: 3 },
  { id: 'EV103', title: 'Data Visualization Basics', category: 'Technology', date: '2026-11-14', time: '11:00', seats: 5 },
  { id: 'EV104', title: 'Personal Finance Essentials', category: 'Life Skills', date: '2026-11-16', time: '16:00', seats: 4 },
  { id: 'EV105', title: 'Public Speaking Practice', category: 'Life Skills', date: '2026-11-18', time: '10:30', seats: 3 },
  { id: 'EV106', title: 'Digital Illustration Studio', category: 'Arts', date: '2026-11-20', time: '13:00', seats: 2 },
]

const STORAGE_KEY = 'community-learning-centre-registrations'
const CATEGORIES = ['All', 'Technology', 'Arts', 'Life Skills']
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function readRegistrations() {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY)
    if (!saved) return { registrations: [], error: '' }

    const parsed = JSON.parse(saved)
    if (!Array.isArray(parsed)) throw new Error('Stored registrations are not a list.')

    const registrations = parsed.filter((registration) =>
      registration
      && typeof registration.id === 'string'
      && typeof registration.eventId === 'string'
      && EVENTS.some((event) => event.id === registration.eventId)
      && typeof registration.name === 'string'
      && typeof registration.email === 'string',
    )
    return { registrations, error: '' }
  } catch {
    return { registrations: [], error: 'Saved registrations could not be read. New registrations will still work in this session.' }
  }
}

function formatDate(date) {
  return new Intl.DateTimeFormat('en', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${date}T00:00:00`))
}

function formatTime(time) {
  return new Intl.DateTimeFormat('en', { hour: 'numeric', minute: '2-digit' }).format(new Date(`2026-01-01T${time}:00`))
}

function AppLayout({ registrations, onRegister, onCancel, storageError, onClearStorageError }) {
  const location = useLocation()
  const registrationCount = registrations.length

  return (
    <div className="app-shell">
      <header className="site-header">
        <Link className="brand" to="/" aria-label="Gather home">
          <span className="brand-mark" aria-hidden="true">g.</span>
          <span>gather<span className="brand-period">.</span></span>
        </Link>
        <nav className="main-nav" aria-label="Main navigation">
          <NavLink to="/" end>Explore events</NavLink>
          <NavLink to="/registrations">
            My registrations <span className="nav-count">{registrationCount}</span>
          </NavLink>
        </nav>
        <div className="header-note"><span className="online-dot" /> Community learning, together</div>
      </header>

      <main>
        {storageError && (
          <div className="storage-alert" role="alert">
            {storageError}
            <button type="button" onClick={onClearStorageError} aria-label="Dismiss message">×</button>
          </div>
        )}
        <Routes>
          <Route
            path="/"
            element={<EventsPage registrations={registrations} onRegister={onRegister} />}
          />
          <Route
            path="/registrations"
            element={<RegistrationsPage registrations={registrations} onCancel={onCancel} />}
          />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <span>Good things happen when we learn together.</span>
        <span>© 2026 Gather Community Centre</span>
      </footer>
      {location.pathname !== '/registrations' && <span className="sr-only" aria-live="polite">{registrationCount} active registrations</span>}
    </div>
  )
}

function EventsPage({ registrations, onRegister }) {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const [selectedEvent, setSelectedEvent] = useState(null)
  const [notice, setNotice] = useState('')

  const filteredEvents = useMemo(() => EVENTS.filter((event) => {
    const matchesTitle = event.title.toLowerCase().includes(query.trim().toLowerCase())
    return matchesTitle && (category === 'All' || event.category === category)
  }), [category, query])

  const availableSeats = (event) => Math.max(0, event.seats - registrations.filter((item) => item.eventId === event.id).length)

  function submitRegistration(attendee) {
    const result = onRegister(selectedEvent, attendee)
    if (result.error) {
      return result
    }
    setSelectedEvent(null)
    setNotice(`You're registered for ${selectedEvent.title}. See you there!`)
    return result
  }

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> A place to grow</div>
          <h1>Make room for<br /><em>something new.</em></h1>
          <p>Small gatherings. Useful skills. Fresh perspectives.<br className="desktop-break" /> Find your next moment of learning.</p>
          <a className="text-link" href="#events">Find your event <span aria-hidden="true">↓</span></a>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-sun" />
          <div className="art-orbit orbit-one" />
          <div className="art-orbit orbit-two" />
          <div className="art-card art-card-one"><span>LEARN</span><strong>by doing.</strong></div>
          <div className="art-card art-card-two"><span>✳</span><small>Curiosity<br />lives here</small></div>
          <div className="art-spark spark-one">✳</div>
          <div className="art-spark spark-two">✦</div>
        </div>
        <div className="hero-caption"><span>01 — 06</span><span>Find a little inspiration</span></div>
      </section>

      <section className="events-section" id="events">
        <div className="section-heading">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" /> The upcoming sessions</div>
            <h2>Pick up a new skill.</h2>
          </div>
          <p>Thoughtful workshops for curious minds.<br />Come as you are; leave with something new.</p>
        </div>

        <div className="event-tools">
          <label className="search-field">
            <span className="search-icon" aria-hidden="true">⌕</span>
            <span className="sr-only">Search events by title</span>
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search events..." />
            {query && <button type="button" onClick={() => setQuery('')} aria-label="Clear search">×</button>}
          </label>
          <div className="category-filters" aria-label="Filter by category">
            {CATEGORIES.map((item) => (
              <button
                className={category === item ? 'filter-chip active' : 'filter-chip'}
                key={item}
                onClick={() => setCategory(item)}
                type="button"
                aria-pressed={category === item}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        {notice && <div className="success-alert" role="status">{notice}<button type="button" onClick={() => setNotice('')} aria-label="Dismiss confirmation">×</button></div>}

        <div className="event-grid">
          {filteredEvents.map((event, index) => (
            <EventCard
              event={event}
              available={availableSeats(event)}
              index={index}
              key={event.id}
              onRegister={() => { setNotice(''); setSelectedEvent(event) }}
            />
          ))}
        </div>
        {filteredEvents.length === 0 && (
          <div className="empty-state">
            <span className="empty-icon" aria-hidden="true">⌕</span>
            <h3>No events found</h3>
            <p>Try a different title or choose another category.</p>
            <button type="button" className="button button-outline" onClick={() => { setQuery(''); setCategory('All') }}>Clear filters</button>
          </div>
        )}
      </section>
      {selectedEvent && (
        <RegistrationModal
          event={selectedEvent}
          available={availableSeats(selectedEvent)}
          onClose={() => setSelectedEvent(null)}
          onSubmit={submitRegistration}
        />
      )}
    </>
  )
}

function EventCard({ event, available, index, onRegister }) {
  const full = available === 0
  const palettes = ['peach', 'lavender', 'mint', 'yellow', 'blue', 'rose']
  return (
    <article className="event-card">
      <div className={`event-art ${palettes[index % palettes.length]}`} aria-hidden="true">
        <span className="event-art-number">{String(index + 1).padStart(2, '0')}</span>
        <span className="event-art-symbol">{event.category === 'Technology' ? '⌘' : event.category === 'Arts' ? '✳' : '↗'}</span>
        <span className="event-art-label">{event.category}</span>
      </div>
      <div className="event-card-body">
        <div className="event-meta"><span className="category-label">{event.category}</span><span className={full ? 'seats-label full' : 'seats-label'}>{full ? `0 of ${event.seats} seats · Fully booked` : `${available} of ${event.seats} seats left`}</span></div>
        <h3>{event.title}</h3>
        <div className="event-details">
          <span><span aria-hidden="true">◷</span> {formatDate(event.date)}</span>
          <span><span aria-hidden="true">◌</span> {formatTime(event.time)}</span>
        </div>
        <button className={full ? 'button button-disabled' : 'button button-dark'} type="button" disabled={full} onClick={onRegister}>
          {full ? 'Fully booked' : 'Save my seat'} {!full && <span aria-hidden="true">↗</span>}
        </button>
      </div>
    </article>
  )
}

function RegistrationModal({ event, available, onClose, onSubmit }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [errors, setErrors] = useState({})
  const [formError, setFormError] = useState('')

  function submit(eventObject) {
    eventObject.preventDefault()
    const nextErrors = {}
    if (!name.trim()) nextErrors.name = 'Please enter your full name.'
    if (!email.trim()) nextErrors.email = 'Please enter your email address.'
    else if (!EMAIL_PATTERN.test(email.trim())) nextErrors.email = 'Please enter a valid email address.'
    setErrors(nextErrors)
    setFormError('')
    if (Object.keys(nextErrors).length > 0) return
    const result = onSubmit({ name: name.trim(), email: email.trim() })
    if (result?.error) setFormError(result.error)
  }

  return (
    <div className="modal-backdrop" onMouseDown={(eventObject) => { if (eventObject.target === eventObject.currentTarget) onClose() }}>
      <section className="registration-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <button className="modal-close" type="button" onClick={onClose} aria-label="Close registration form">×</button>
        <div className="eyebrow"><span className="eyebrow-line" /> Save your seat</div>
        <h2 id="modal-title">{event.title}</h2>
        <p className="modal-date">{formatDate(event.date)} <span>·</span> {formatTime(event.time)} <span>·</span> {available} {available === 1 ? 'seat' : 'seats'} remaining</p>
        {formError && <p className="form-error form-error-summary" role="alert">{formError}</p>}
        {available === 0 ? (
          <div className="empty-state compact"><p>This event is fully booked.</p></div>
        ) : (
          <form onSubmit={submit} noValidate>
            <label className="form-field">
              <span>Full name</span>
              <input autoFocus value={name} onChange={(eventObject) => setName(eventObject.target.value)} aria-invalid={Boolean(errors.name)} aria-describedby={errors.name ? 'name-error' : undefined} placeholder="e.g. Alex Morgan" />
              {errors.name && <span className="form-error" id="name-error">{errors.name}</span>}
            </label>
            <label className="form-field">
              <span>Email address</span>
              <input type="email" value={email} onChange={(eventObject) => setEmail(eventObject.target.value)} aria-invalid={Boolean(errors.email)} aria-describedby={errors.email ? 'email-error' : undefined} placeholder="you@example.com" />
              {errors.email && <span className="form-error" id="email-error">{errors.email}</span>}
            </label>
            <button className="button button-dark submit-button" type="submit">Confirm registration <span aria-hidden="true">↗</span></button>
          </form>
        )}
        <p className="privacy-note">Your details are only used to manage this event registration.</p>
      </section>
    </div>
  )
}

function RegistrationsPage({ registrations, onCancel }) {
  const navigate = useNavigate()
  return (
    <section className="registrations-section">
      <div className="eyebrow"><span className="eyebrow-line" /> Your learning calendar</div>
      <div className="registrations-heading">
        <div><h1>Your registrations<span className="heading-period">.</span></h1><p>All the good things you’ve signed up for.</p></div>
        <Link className="button button-outline" to="/">Explore events <span aria-hidden="true">↗</span></Link>
      </div>
      {registrations.length > 0 ? (
        <div className="registration-list">
          {registrations.map((registration) => {
            const event = EVENTS.find((item) => item.id === registration.eventId)
            if (!event) return null
            return (
              <article className="registration-row" key={registration.id}>
                <div className="registration-date"><strong>{new Intl.DateTimeFormat('en', { day: '2-digit' }).format(new Date(`${event.date}T00:00:00`))}</strong><span>{new Intl.DateTimeFormat('en', { month: 'short' }).format(new Date(`${event.date}T00:00:00`))}</span></div>
                <div className="registration-info"><span className="category-label">{event.category}</span><h2>{event.title}</h2><p>{formatDate(event.date)} · {formatTime(event.time)}</p></div>
                <div className="attendee-info"><span>Attendee</span><strong>{registration.name}</strong><p>{registration.email}</p></div>
                <button className="cancel-button" type="button" onClick={() => onCancel(registration)}>Cancel registration</button>
              </article>
            )
          })}
        </div>
      ) : (
        <div className="empty-state registrations-empty">
          <span className="empty-icon" aria-hidden="true">✳</span>
          <h2>No registrations yet</h2>
          <p>Your next new skill is just around the corner.</p>
          <button type="button" className="button button-dark" onClick={() => navigate('/')}>Browse upcoming events <span aria-hidden="true">↗</span></button>
        </div>
      )}
    </section>
  )
}

function NotFoundPage() {
  return (
    <div className="empty-state registrations-empty">
      <span className="empty-icon" aria-hidden="true">?</span>
      <h2>That page isn’t here</h2>
      <Link className="button button-dark" to="/">Back to events</Link>
    </div>
  )
}

function App() {
  const [initialState] = useState(readRegistrations)
  const [registrations, setRegistrations] = useState(initialState.registrations)
  const [storageError, setStorageError] = useState(initialState.error)

  function updateRegistrations(nextRegistrations) {
    setRegistrations(nextRegistrations)
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextRegistrations))
      setStorageError('')
    } catch {
      setStorageError('Your registration could not be saved in this browser. Check your browser storage settings.')
    }
  }

  function register(event, attendee) {
    const eventRegistrations = registrations.filter((registration) => registration.eventId === event.id)
    if (eventRegistrations.length >= event.seats) return { error: 'This event is now fully booked.' }
    const duplicate = eventRegistrations.some((registration) => registration.email.trim().toLowerCase() === attendee.email.trim().toLowerCase())
    if (duplicate) return { error: 'This email is already registered for this event.' }
    const registration = { id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, eventId: event.id, name: attendee.name, email: attendee.email }
    updateRegistrations([...registrations, registration])
    return { error: '' }
  }

  function cancel(registration) {
    if (!window.confirm(`Cancel ${registration.name}'s registration for ${EVENTS.find((event) => event.id === registration.eventId)?.title}?`)) return
    updateRegistrations(registrations.filter((item) => item.id !== registration.id))
  }

  return (
    <BrowserRouter>
      <AppLayout
        registrations={registrations}
        onRegister={register}
        onCancel={cancel}
        storageError={storageError}
        onClearStorageError={() => setStorageError('')}
      />
    </BrowserRouter>
  )
}

export default App
