from pydantic import BaseModel, ValidationError, Field
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s - %(message)s"
)

# Pydantic model
class Employee(BaseModel):
    name: str
    age: int = Field(gt=18)
    email: str
    salary: float = Field(gt=0)


#sample input
data={
    "name":"deepika",
    "age":18,
    "email":"deeps@gmail.com",
    "salary":50000
}

try:
    employee = Employee(**data)
    logging.info("employee data validated successfully")
    print(employee)

except ValidationError as e:
    print(e)
