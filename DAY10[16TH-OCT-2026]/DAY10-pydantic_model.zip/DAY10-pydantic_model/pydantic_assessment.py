# 1. Create a Pydantic model called Registration .

from pydantic import BaseModel, Field
import logging


class Registration(BaseModel):
    registration_id: str
    name :str
    email :str
    age : int = Field(gt=18)
    ticket_type :str
    amount : float= Field(gt=0)

# 3. Validate that age must be at least 18 .


# 4. Validate that amount must be greater than 0 .


# 5. Restrict ticket_type to:
# Standard
# Premium
# VIP
# 2. Add these fields:
# registration_id
# name
# email
# age
# ticket_type
# amount


# 6. Load registrations.json and validate each record using the Pydantic model.
import json
with open("registrations.json","r") as file:
    data=json.load(file)

for item in data:
    try:
        Registration(**item)
        print("validated:",item)
    except Exception as e:
        print("skipped invalid record:",item.get("registration_id"))

# 7. Print only the valid registrations
for item in data:
    try:
        Registration(**item)
        print("validated:",item)
    except Exception:
        pass

# 8. Catch Pydantic validation errors and print a simple message showing:
# registration ID
# field with error
# error message
for item in data:
    try:
        Registration(**item)
        print("validated:",item)
    except Exception as e:
        reg_id=item.get("registration_id")
        for error in e.errors():
            field_with_error=error['loc'][0]
            error_message=error['msg']
        print(reg_id,"field_with_error is:",field_with_error,",",error_message)
# 9. Serialize one valid Pydantic object into a Python dictionary.
dictionary_item=None
for item in data:
    try:
        valid_obj=Registration(**item)
        if dictionary_item is None:
            dictionary_item=valid_obj.model_dump()
    except Exception as e:
        print(e)
print(dictionary_item)

# 10. Serialize one valid object into JSON.
json_item=None
for item in data:
    try:
        valid_obj=Registration(**item)
        if json_item is None:
            json_item=valid_obj.model_dump_json()
    except Exception as e:
        print(e)
print(json_item)

# 11. Save all valid registrations into:
# valid_registrations.json
valid_regi=[]
for item in data:
    try:
        valid_obj=Registration(**item)
        valid_regi.append(valid_obj.model_dump())
    except Exception:
        pass
with open("valid_registrations.json","w") as file:
    json.dump(valid_regi,file)

# 12. Configure Python logging with these levels:
# INFO
# WARNING
# ERROR
# Configure logging
# 16. Save logs into:
# registration.log
logging.basicConfig(
    filename="registrations.log",
    level=logging.INFO,
    format="%(levelname)s - %(message)s"
)
# 17. Add error handling for:
# file not found
# invalid JSON
# validation failure
# 18. If registrations.json does not exist, the program should not crash. It should print/log a
# meaningful error
try:
    with open("valid_registrations.json","r") as file:
        data=json.load(file)
except FileNotFoundError:
    logging.error(f"registrations.json not found")
    data=[]
except json.JSONDecodeError:
    logging.error(f"No valid registrations.json it contains ivalid json data.")
    data=[]

# 13. Log an INFO message when a registration is successfully validated.
# Example expected style:
# INFO - Registration R101 validated successfully
# 14. Log an ERROR message when validation fails.
# 15. Log a WARNING when the ticket type is VIP .
for item in data:
    try:
        valid_obj=Registration(**item)
        logging.info(f"registration:{valid_obj.registration_id}validated successfully")
    except Exception as e:
        print(e)

# 19. Modify one JSON record so that age contains text instead of a number and observe how
# Pydantic handles it.
# 20. At the end, print a summary:
# Total records:

# Valid records:
# Invalid records:
valid_rec=0
invalid_rec=0
with open("registrations.json","r") as file:
    data=json.load(file)
for item in data:
    print("Total REcords:", len(data))
    try:
        valid_obj=Registration(**item)
        valid_rec +=1
        logging.info(f"registration:{valid_obj.registration_id}validated successfully")
    except Exception as e:
        print(e)
        invalid_rec+=1
print("valid_rec:",valid_rec)
print("invalid_rec:",invalid_rec)